﻿
namespace PresentationsLager.Meny.Association
{
    partial class AssociationLärareKurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewUndervisarI = new System.Windows.Forms.DataGridView();
            this.dataGridViewTillgängligaKurser = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.LäggTillAssBtn = new System.Windows.Forms.Button();
            this.TaBortAssBtn = new System.Windows.Forms.Button();
            this.TillbakaAssBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUndervisarI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTillgängligaKurser)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewUndervisarI
            // 
            this.dataGridViewUndervisarI.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewUndervisarI.Location = new System.Drawing.Point(343, 12);
            this.dataGridViewUndervisarI.Name = "dataGridViewUndervisarI";
            this.dataGridViewUndervisarI.RowHeadersWidth = 51;
            this.dataGridViewUndervisarI.RowTemplate.Height = 24;
            this.dataGridViewUndervisarI.Size = new System.Drawing.Size(445, 203);
            this.dataGridViewUndervisarI.TabIndex = 0;
            this.dataGridViewUndervisarI.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewUndervisarI_CellClick);
            // 
            // dataGridViewTillgängligaKurser
            // 
            this.dataGridViewTillgängligaKurser.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTillgängligaKurser.Location = new System.Drawing.Point(343, 238);
            this.dataGridViewTillgängligaKurser.Name = "dataGridViewTillgängligaKurser";
            this.dataGridViewTillgängligaKurser.RowHeadersWidth = 51;
            this.dataGridViewTillgängligaKurser.RowTemplate.Height = 24;
            this.dataGridViewTillgängligaKurser.Size = new System.Drawing.Size(445, 200);
            this.dataGridViewTillgängligaKurser.TabIndex = 1;
            this.dataGridViewTillgängligaKurser.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTillgängligaKurser_CellClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(205, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 17);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tillgängliga Lärare::";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(209, 238);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 17);
            this.label2.TabIndex = 3;
            this.label2.Text = "Tillgängliga kurser:";
            // 
            // LäggTillAssBtn
            // 
            this.LäggTillAssBtn.Location = new System.Drawing.Point(33, 92);
            this.LäggTillAssBtn.Name = "LäggTillAssBtn";
            this.LäggTillAssBtn.Size = new System.Drawing.Size(159, 50);
            this.LäggTillAssBtn.TabIndex = 4;
            this.LäggTillAssBtn.Text = "Lägg till";
            this.LäggTillAssBtn.UseVisualStyleBackColor = true;
            this.LäggTillAssBtn.Click += new System.EventHandler(this.LäggTillAssBtn_Click);
            // 
            // TaBortAssBtn
            // 
            this.TaBortAssBtn.Location = new System.Drawing.Point(33, 202);
            this.TaBortAssBtn.Name = "TaBortAssBtn";
            this.TaBortAssBtn.Size = new System.Drawing.Size(159, 43);
            this.TaBortAssBtn.TabIndex = 5;
            this.TaBortAssBtn.Text = "Ta Bort";
            this.TaBortAssBtn.UseVisualStyleBackColor = true;
            this.TaBortAssBtn.Click += new System.EventHandler(this.TaBortAssBtn_Click);
            // 
            // TillbakaAssBtn
            // 
            this.TillbakaAssBtn.Location = new System.Drawing.Point(24, 397);
            this.TillbakaAssBtn.Name = "TillbakaAssBtn";
            this.TillbakaAssBtn.Size = new System.Drawing.Size(168, 41);
            this.TillbakaAssBtn.TabIndex = 6;
            this.TillbakaAssBtn.Text = "Tillbaka";
            this.TillbakaAssBtn.UseVisualStyleBackColor = true;
            this.TillbakaAssBtn.Click += new System.EventHandler(this.TillbakaAssBtn_Click);
            // 
            // AssociationLärareKurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 450);
            this.Controls.Add(this.TillbakaAssBtn);
            this.Controls.Add(this.TaBortAssBtn);
            this.Controls.Add(this.LäggTillAssBtn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewTillgängligaKurser);
            this.Controls.Add(this.dataGridViewUndervisarI);
            this.Name = "AssociationLärareKurs";
            this.Text = "AssociationLärareKurs";
            this.Load += new System.EventHandler(this.AssociationLärareKurs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewUndervisarI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTillgängligaKurser)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewUndervisarI;
        private System.Windows.Forms.DataGridView dataGridViewTillgängligaKurser;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button LäggTillAssBtn;
        private System.Windows.Forms.Button TaBortAssBtn;
        private System.Windows.Forms.Button TillbakaAssBtn;
    }
}