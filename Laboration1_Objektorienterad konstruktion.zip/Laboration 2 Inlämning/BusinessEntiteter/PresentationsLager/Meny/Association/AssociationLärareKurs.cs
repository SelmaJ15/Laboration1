﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.Association
{
    /// <summary>
    /// Syftet var att se tillgänliga kurser samt lärare och skapa en association mellan dessa entiteter där 
    /// man kan ta bort och lägga till assoicationen 
    /// </summary>
    public partial class AssociationLärareKurs : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        private Kurs ValdKurs;
        private Lärare ValdLärare;
        public AssociationLärareKurs()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void AssociationLärareKurs_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewTillOchUnder();
        }

        private void UppdateraDataGridViewTillOchUnder()
        {
            dataGridViewTillgängligaKurser.DataSource = new BindingList<Kurs>(serviceLager.HämtaListaMedKurs());
            dataGridViewUndervisarI.DataSource = new BindingList<Lärare>(serviceLager.HämtaListaMedLärare());
        }

        private void LäggTillAssBtn_Click(object sender, EventArgs e)
        {
            ///Fungerar tyvärr inte då vi försökte lägga till selectedows från en grid till en annan ///
        }
        private void UppdateraAssBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewTillOchUnder();
        }

        private void dataGridViewTillgängligaKurser_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ValdKurs = dataGridViewTillgängligaKurser.SelectedRows[0].DataBoundItem as Kurs;
        }

        private void TillbakaAssBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            HuvudMeny huvudMeny = new HuvudMeny();
            huvudMeny.Show();
        }

        private void dataGridViewUndervisarI_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ValdLärare = dataGridViewUndervisarI.SelectedRows[0].DataBoundItem as Lärare;
        }

        private void TaBortAssBtn_Click(object sender, EventArgs e)
        {
            ///Fungerar tyvärr inte då vi försökte lägga till selectedows från en grid till en annan ///
        }
    }
}
