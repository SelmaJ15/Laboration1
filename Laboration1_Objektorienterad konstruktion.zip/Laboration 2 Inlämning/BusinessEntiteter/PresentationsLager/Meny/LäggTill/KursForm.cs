﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class KursForm : Form
    {
        private ServiceLager ServiceLager;
        public KursForm(ServiceLager serviceLager)
        {
            InitializeComponent();

            ServiceLager = serviceLager;
        }

        private void LäggTillKursFormBtn_Click(object sender, EventArgs e)
        {
            Kurs kursNy = new Kurs();

            kursNy.Namn = textBoxNamn.Text;
            kursNy.Högskolepoäng = int.Parse(textBoxHp.Text);
            kursNy.StartDatum = textBoxStartDatum.Text;
            kursNy.SlutDatum = textBoxSlutDatum.Text;

            ServiceLager.LäggTillKurs(kursNy);

            this.Close();
        }

        private void AvbrytLäggTillKursFormBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
