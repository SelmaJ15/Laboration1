﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class LäggTillLärare : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public LäggTillLärare()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void LäggTillLärare_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillLärare();
        }

        private void UppdateraDataGridViewLäggTillLärare()
        {
            dataGridViewLäggTillLärare.DataSource = new BindingList<Lärare>(serviceLager.HämtaListaMedLärare());
        }

        private void LäggTillLärareBtn_Click(object sender, EventArgs e)
        {
            LärareForm lärareForm = new LärareForm(serviceLager);
            lärareForm.Show();
        }

        private void UppdateraLäggTillLärareBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillLärare();
        }

        private void TillbakaLäggTillLärareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillData läggTillData = new LäggTillData();
            läggTillData.Show();
        }
    }
}
