﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class StudentForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxFörNamn = new System.Windows.Forms.TextBox();
            this.textBoxEfterNamn = new System.Windows.Forms.TextBox();
            this.textBoxPersonNmr = new System.Windows.Forms.TextBox();
            this.textBoxEPost = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.LäggTillStudentFormBtn = new System.Windows.Forms.Button();
            this.AvbrytStudentFormBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxFörNamn
            // 
            this.textBoxFörNamn.Location = new System.Drawing.Point(413, 83);
            this.textBoxFörNamn.Name = "textBoxFörNamn";
            this.textBoxFörNamn.Size = new System.Drawing.Size(229, 22);
            this.textBoxFörNamn.TabIndex = 0;
            // 
            // textBoxEfterNamn
            // 
            this.textBoxEfterNamn.Location = new System.Drawing.Point(413, 128);
            this.textBoxEfterNamn.Name = "textBoxEfterNamn";
            this.textBoxEfterNamn.Size = new System.Drawing.Size(229, 22);
            this.textBoxEfterNamn.TabIndex = 1;
            // 
            // textBoxPersonNmr
            // 
            this.textBoxPersonNmr.Location = new System.Drawing.Point(413, 179);
            this.textBoxPersonNmr.Name = "textBoxPersonNmr";
            this.textBoxPersonNmr.Size = new System.Drawing.Size(229, 22);
            this.textBoxPersonNmr.TabIndex = 2;
            // 
            // textBoxEPost
            // 
            this.textBoxEPost.Location = new System.Drawing.Point(413, 232);
            this.textBoxEPost.Name = "textBoxEPost";
            this.textBoxEPost.Size = new System.Drawing.Size(229, 22);
            this.textBoxEPost.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(334, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 4;
            this.label1.Text = "Förnamn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(334, 132);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 5;
            this.label2.Text = "Efternamn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(303, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 17);
            this.label3.TabIndex = 6;
            this.label3.Text = "Personnummer";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(353, 236);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(50, 17);
            this.label4.TabIndex = 7;
            this.label4.Text = "E-Post";
            // 
            // LäggTillStudentFormBtn
            // 
            this.LäggTillStudentFormBtn.Location = new System.Drawing.Point(427, 321);
            this.LäggTillStudentFormBtn.Name = "LäggTillStudentFormBtn";
            this.LäggTillStudentFormBtn.Size = new System.Drawing.Size(215, 48);
            this.LäggTillStudentFormBtn.TabIndex = 8;
            this.LäggTillStudentFormBtn.Text = "Lägg till";
            this.LäggTillStudentFormBtn.UseVisualStyleBackColor = true;
            this.LäggTillStudentFormBtn.Click += new System.EventHandler(this.LäggTillStudentFormBtn_Click);
            // 
            // AvbrytStudentFormBtn
            // 
            this.AvbrytStudentFormBtn.Location = new System.Drawing.Point(177, 321);
            this.AvbrytStudentFormBtn.Name = "AvbrytStudentFormBtn";
            this.AvbrytStudentFormBtn.Size = new System.Drawing.Size(188, 48);
            this.AvbrytStudentFormBtn.TabIndex = 9;
            this.AvbrytStudentFormBtn.Text = "Avbryt";
            this.AvbrytStudentFormBtn.UseVisualStyleBackColor = true;
            this.AvbrytStudentFormBtn.Click += new System.EventHandler(this.AvbrytStudentFormBtn_Click);
            // 
            // StudentForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.AvbrytStudentFormBtn);
            this.Controls.Add(this.LäggTillStudentFormBtn);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxEPost);
            this.Controls.Add(this.textBoxPersonNmr);
            this.Controls.Add(this.textBoxEfterNamn);
            this.Controls.Add(this.textBoxFörNamn);
            this.Name = "StudentForm";
            this.Text = "StudentForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxFörNamn;
        private System.Windows.Forms.TextBox textBoxEfterNamn;
        private System.Windows.Forms.TextBox textBoxPersonNmr;
        private System.Windows.Forms.TextBox textBoxEPost;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button LäggTillStudentFormBtn;
        private System.Windows.Forms.Button AvbrytStudentFormBtn;
    }
}