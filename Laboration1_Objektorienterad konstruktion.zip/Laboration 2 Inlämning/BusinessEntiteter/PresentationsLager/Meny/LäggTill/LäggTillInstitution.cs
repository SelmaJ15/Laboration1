﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class LäggTillInstitution : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public LäggTillInstitution()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void LäggTillInstitution_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillInst();
        }

        private void UppdateraDataGridViewLäggTillInst()
        {
            dataGridViewLäggTillInst.DataSource = new BindingList<Institution>(serviceLager.HämtaListaMedInstitution());
        }

        private void LäggTillInstBtn_Click(object sender, EventArgs e)
        {
            InstitutionForm institutionForm = new InstitutionForm(serviceLager);
            institutionForm.Show();
        }

        private void UppdateraLäggTillBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillInst();
        }

        private void TillbakaLäggTillInstBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillData läggTillData = new LäggTillData();
            läggTillData.Show();
        }
    }
}
