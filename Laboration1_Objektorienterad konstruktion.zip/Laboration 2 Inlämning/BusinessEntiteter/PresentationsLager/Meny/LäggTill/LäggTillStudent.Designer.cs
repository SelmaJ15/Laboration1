﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class LäggTillStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewLäggTillStudent = new System.Windows.Forms.DataGridView();
            this.LäggTillStudentBtn = new System.Windows.Forms.Button();
            this.UppdateraLäggTillStudentBtn = new System.Windows.Forms.Button();
            this.TillbakaLäggTillStudentBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLäggTillStudent
            // 
            this.dataGridViewLäggTillStudent.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLäggTillStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLäggTillStudent.Location = new System.Drawing.Point(223, 0);
            this.dataGridViewLäggTillStudent.Name = "dataGridViewLäggTillStudent";
            this.dataGridViewLäggTillStudent.RowHeadersWidth = 51;
            this.dataGridViewLäggTillStudent.RowTemplate.Height = 24;
            this.dataGridViewLäggTillStudent.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewLäggTillStudent.TabIndex = 0;
            // 
            // LäggTillStudentBtn
            // 
            this.LäggTillStudentBtn.Location = new System.Drawing.Point(4, 286);
            this.LäggTillStudentBtn.Name = "LäggTillStudentBtn";
            this.LäggTillStudentBtn.Size = new System.Drawing.Size(217, 47);
            this.LäggTillStudentBtn.TabIndex = 1;
            this.LäggTillStudentBtn.Text = "Lägg till";
            this.LäggTillStudentBtn.UseVisualStyleBackColor = true;
            this.LäggTillStudentBtn.Click += new System.EventHandler(this.LäggTillStudentBtn_Click);
            // 
            // UppdateraLäggTillStudentBtn
            // 
            this.UppdateraLäggTillStudentBtn.Location = new System.Drawing.Point(4, 339);
            this.UppdateraLäggTillStudentBtn.Name = "UppdateraLäggTillStudentBtn";
            this.UppdateraLäggTillStudentBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraLäggTillStudentBtn.TabIndex = 2;
            this.UppdateraLäggTillStudentBtn.Text = "Uppdatera";
            this.UppdateraLäggTillStudentBtn.UseVisualStyleBackColor = true;
            this.UppdateraLäggTillStudentBtn.Click += new System.EventHandler(this.UppdateraLäggTillStudentBtn_Click);
            // 
            // TillbakaLäggTillStudentBtn
            // 
            this.TillbakaLäggTillStudentBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaLäggTillStudentBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaLäggTillStudentBtn.Location = new System.Drawing.Point(0, 397);
            this.TillbakaLäggTillStudentBtn.Name = "TillbakaLäggTillStudentBtn";
            this.TillbakaLäggTillStudentBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakaLäggTillStudentBtn.TabIndex = 3;
            this.TillbakaLäggTillStudentBtn.Text = "Tillbaka";
            this.TillbakaLäggTillStudentBtn.UseVisualStyleBackColor = false;
            this.TillbakaLäggTillStudentBtn.Click += new System.EventHandler(this.TillbakaLäggTillStudentBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(21, 40);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Lägg till data";
            // 
            // LäggTillStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaLäggTillStudentBtn);
            this.Controls.Add(this.UppdateraLäggTillStudentBtn);
            this.Controls.Add(this.LäggTillStudentBtn);
            this.Controls.Add(this.dataGridViewLäggTillStudent);
            this.Name = "LäggTillStudent";
            this.Text = "LäggTillStudent";
            this.Load += new System.EventHandler(this.LäggTillStudent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLäggTillStudent;
        private System.Windows.Forms.Button LäggTillStudentBtn;
        private System.Windows.Forms.Button UppdateraLäggTillStudentBtn;
        private System.Windows.Forms.Button TillbakaLäggTillStudentBtn;
        private System.Windows.Forms.Label label1;
    }
}