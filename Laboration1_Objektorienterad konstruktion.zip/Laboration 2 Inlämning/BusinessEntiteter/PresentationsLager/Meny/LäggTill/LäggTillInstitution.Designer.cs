﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class LäggTillInstitution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewLäggTillInst = new System.Windows.Forms.DataGridView();
            this.LäggTillInstBtn = new System.Windows.Forms.Button();
            this.UppdateraLäggTillBtn = new System.Windows.Forms.Button();
            this.TillbakaLäggTillInstBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillInst)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLäggTillInst
            // 
            this.dataGridViewLäggTillInst.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLäggTillInst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLäggTillInst.Location = new System.Drawing.Point(220, 1);
            this.dataGridViewLäggTillInst.Name = "dataGridViewLäggTillInst";
            this.dataGridViewLäggTillInst.RowHeadersWidth = 51;
            this.dataGridViewLäggTillInst.RowTemplate.Height = 24;
            this.dataGridViewLäggTillInst.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewLäggTillInst.TabIndex = 0;
            // 
            // LäggTillInstBtn
            // 
            this.LäggTillInstBtn.Location = new System.Drawing.Point(3, 295);
            this.LäggTillInstBtn.Name = "LäggTillInstBtn";
            this.LäggTillInstBtn.Size = new System.Drawing.Size(217, 47);
            this.LäggTillInstBtn.TabIndex = 1;
            this.LäggTillInstBtn.Text = "Lägg till";
            this.LäggTillInstBtn.UseVisualStyleBackColor = true;
            this.LäggTillInstBtn.Click += new System.EventHandler(this.LäggTillInstBtn_Click);
            // 
            // UppdateraLäggTillBtn
            // 
            this.UppdateraLäggTillBtn.Location = new System.Drawing.Point(3, 348);
            this.UppdateraLäggTillBtn.Name = "UppdateraLäggTillBtn";
            this.UppdateraLäggTillBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraLäggTillBtn.TabIndex = 2;
            this.UppdateraLäggTillBtn.Text = "Uppdatera";
            this.UppdateraLäggTillBtn.UseVisualStyleBackColor = true;
            this.UppdateraLäggTillBtn.Click += new System.EventHandler(this.UppdateraLäggTillBtn_Click);
            // 
            // TillbakaLäggTillInstBtn
            // 
            this.TillbakaLäggTillInstBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaLäggTillInstBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaLäggTillInstBtn.Location = new System.Drawing.Point(0, 403);
            this.TillbakaLäggTillInstBtn.Name = "TillbakaLäggTillInstBtn";
            this.TillbakaLäggTillInstBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakaLäggTillInstBtn.TabIndex = 3;
            this.TillbakaLäggTillInstBtn.Text = "Tillbaka";
            this.TillbakaLäggTillInstBtn.UseVisualStyleBackColor = false;
            this.TillbakaLäggTillInstBtn.Click += new System.EventHandler(this.TillbakaLäggTillInstBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Lägg till data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(84, 170);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 17);
            this.label2.TabIndex = 5;
            // 
            // LäggTillInstitution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(798, 453);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaLäggTillInstBtn);
            this.Controls.Add(this.UppdateraLäggTillBtn);
            this.Controls.Add(this.LäggTillInstBtn);
            this.Controls.Add(this.dataGridViewLäggTillInst);
            this.Name = "LäggTillInstitution";
            this.Text = "LäggTillInstitution";
            this.Load += new System.EventHandler(this.LäggTillInstitution_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillInst)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLäggTillInst;
        private System.Windows.Forms.Button LäggTillInstBtn;
        private System.Windows.Forms.Button UppdateraLäggTillBtn;
        private System.Windows.Forms.Button TillbakaLäggTillInstBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}