﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class LäggTillKurs : Form
    {
        ServiceLager serviceLager = new ServiceLager();

        public LäggTillKurs()
        {
            InitializeComponent();

            serviceLager.Seed();
        }

        private void LäggTillKurs_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillKurs();
        }

        private void UppdateraDataGridViewLäggTillKurs()
        {
            dataGridViewLäggTillKurs.DataSource = new BindingList<Kurs>(serviceLager.HämtaListaMedKurs());
        }

        private void UppdateraLäggTillKursBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillKurs();
        }

        private void LäggTillKursBtn_Click(object sender, EventArgs e)
        {
            KursForm kursForm = new KursForm(serviceLager);
            kursForm.Show();
        }

        private void TillbakaLäggTillKursBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillData läggTillData = new LäggTillData();
            läggTillData.Show();
        }
    }
}
