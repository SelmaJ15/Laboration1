﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class LärareForm : Form
    {
        private ServiceLager ServiceLager;
        public LärareForm(ServiceLager serviceLager)
        {
            InitializeComponent();
            ServiceLager = serviceLager;
        }

        private void LäggTillLärareFormBtn_Click(object sender, EventArgs e)
        {
            Lärare lärareNy = new Lärare();

            lärareNy.FörNamn = textBoxFörNamn.Text;
            lärareNy.EfterNamn = textBoxEfterNamn.Text;
            lärareNy.PersonNr = int.Parse(textBoxPersonNmr.Text);
            lärareNy.Epost = textBoxEPost.Text;
            lärareNy.Lön = int.Parse(textBoxLön.Text);
            lärareNy.TelefonNmr = int.Parse(textBoxTelefonNmr.Text);

            ServiceLager.LäggTillLärare(lärareNy);

            this.Close();
        }

        private void AvbrytLärareFormBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
