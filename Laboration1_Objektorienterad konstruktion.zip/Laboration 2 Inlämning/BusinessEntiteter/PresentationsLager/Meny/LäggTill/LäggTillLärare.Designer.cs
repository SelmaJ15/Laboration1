﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class LäggTillLärare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewLäggTillLärare = new System.Windows.Forms.DataGridView();
            this.LäggTillLärareBtn = new System.Windows.Forms.Button();
            this.UppdateraLäggTillLärareBtn = new System.Windows.Forms.Button();
            this.TillbakaLäggTillLärareBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillLärare)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLäggTillLärare
            // 
            this.dataGridViewLäggTillLärare.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLäggTillLärare.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLäggTillLärare.Location = new System.Drawing.Point(223, 2);
            this.dataGridViewLäggTillLärare.Name = "dataGridViewLäggTillLärare";
            this.dataGridViewLäggTillLärare.RowHeadersWidth = 51;
            this.dataGridViewLäggTillLärare.RowTemplate.Height = 24;
            this.dataGridViewLäggTillLärare.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewLäggTillLärare.TabIndex = 0;
            // 
            // LäggTillLärareBtn
            // 
            this.LäggTillLärareBtn.Location = new System.Drawing.Point(4, 296);
            this.LäggTillLärareBtn.Name = "LäggTillLärareBtn";
            this.LäggTillLärareBtn.Size = new System.Drawing.Size(217, 47);
            this.LäggTillLärareBtn.TabIndex = 1;
            this.LäggTillLärareBtn.Text = "Lägg till";
            this.LäggTillLärareBtn.UseVisualStyleBackColor = true;
            this.LäggTillLärareBtn.Click += new System.EventHandler(this.LäggTillLärareBtn_Click);
            // 
            // UppdateraLäggTillLärareBtn
            // 
            this.UppdateraLäggTillLärareBtn.Location = new System.Drawing.Point(4, 349);
            this.UppdateraLäggTillLärareBtn.Name = "UppdateraLäggTillLärareBtn";
            this.UppdateraLäggTillLärareBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraLäggTillLärareBtn.TabIndex = 2;
            this.UppdateraLäggTillLärareBtn.Text = "Uppdatera";
            this.UppdateraLäggTillLärareBtn.UseVisualStyleBackColor = true;
            this.UppdateraLäggTillLärareBtn.Click += new System.EventHandler(this.UppdateraLäggTillLärareBtn_Click);
            // 
            // TillbakaLäggTillLärareBtn
            // 
            this.TillbakaLäggTillLärareBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaLäggTillLärareBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaLäggTillLärareBtn.Location = new System.Drawing.Point(1, 401);
            this.TillbakaLäggTillLärareBtn.Name = "TillbakaLäggTillLärareBtn";
            this.TillbakaLäggTillLärareBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakaLäggTillLärareBtn.TabIndex = 3;
            this.TillbakaLäggTillLärareBtn.Text = "Tillbaka";
            this.TillbakaLäggTillLärareBtn.UseVisualStyleBackColor = false;
            this.TillbakaLäggTillLärareBtn.Click += new System.EventHandler(this.TillbakaLäggTillLärareBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 35);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Lägg till data";
            // 
            // LäggTillLärare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaLäggTillLärareBtn);
            this.Controls.Add(this.UppdateraLäggTillLärareBtn);
            this.Controls.Add(this.LäggTillLärareBtn);
            this.Controls.Add(this.dataGridViewLäggTillLärare);
            this.Name = "LäggTillLärare";
            this.Text = "LäggTillLärare";
            this.Load += new System.EventHandler(this.LäggTillLärare_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillLärare)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLäggTillLärare;
        private System.Windows.Forms.Button LäggTillLärareBtn;
        private System.Windows.Forms.Button UppdateraLäggTillLärareBtn;
        private System.Windows.Forms.Button TillbakaLäggTillLärareBtn;
        private System.Windows.Forms.Label label1;
    }
}