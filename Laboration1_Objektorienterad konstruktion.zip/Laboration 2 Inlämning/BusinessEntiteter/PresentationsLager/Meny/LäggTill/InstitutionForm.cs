﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class InstitutionForm : Form
    {
        private ServiceLager ServiceLager;

        public InstitutionForm(ServiceLager serviceLager)
        {
            InitializeComponent();

            ServiceLager = serviceLager;
        }

        private void LäggTillInstFormBtn_Click(object sender, EventArgs e)
        {
            Institution institutionNy = new Institution();

            institutionNy.Namn = textBoxInstNamn.Text;
            institutionNy.Prefekt = textBoxInstPrefekt.Text;

            ServiceLager.LäggTillInstitution(institutionNy);

            this.Close();
        }

        private void AvbrytInstFormBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
