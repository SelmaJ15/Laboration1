﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class LärareForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBoxFörNamn = new System.Windows.Forms.TextBox();
            this.textBoxEfterNamn = new System.Windows.Forms.TextBox();
            this.textBoxPersonNmr = new System.Windows.Forms.TextBox();
            this.textBoxEPost = new System.Windows.Forms.TextBox();
            this.textBoxLön = new System.Windows.Forms.TextBox();
            this.textBoxTelefonNmr = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.LäggTillLärareFormBtn = new System.Windows.Forms.Button();
            this.AvbrytLärareFormBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBoxFörNamn
            // 
            this.textBoxFörNamn.Location = new System.Drawing.Point(477, 41);
            this.textBoxFörNamn.Name = "textBoxFörNamn";
            this.textBoxFörNamn.Size = new System.Drawing.Size(326, 22);
            this.textBoxFörNamn.TabIndex = 0;
            // 
            // textBoxEfterNamn
            // 
            this.textBoxEfterNamn.Location = new System.Drawing.Point(477, 93);
            this.textBoxEfterNamn.Name = "textBoxEfterNamn";
            this.textBoxEfterNamn.Size = new System.Drawing.Size(326, 22);
            this.textBoxEfterNamn.TabIndex = 1;
            // 
            // textBoxPersonNmr
            // 
            this.textBoxPersonNmr.Location = new System.Drawing.Point(477, 149);
            this.textBoxPersonNmr.Name = "textBoxPersonNmr";
            this.textBoxPersonNmr.Size = new System.Drawing.Size(326, 22);
            this.textBoxPersonNmr.TabIndex = 2;
            // 
            // textBoxEPost
            // 
            this.textBoxEPost.Location = new System.Drawing.Point(477, 204);
            this.textBoxEPost.Name = "textBoxEPost";
            this.textBoxEPost.Size = new System.Drawing.Size(326, 22);
            this.textBoxEPost.TabIndex = 3;
            // 
            // textBoxLön
            // 
            this.textBoxLön.Location = new System.Drawing.Point(477, 255);
            this.textBoxLön.Name = "textBoxLön";
            this.textBoxLön.Size = new System.Drawing.Size(326, 22);
            this.textBoxLön.TabIndex = 4;
            // 
            // textBoxTelefonNmr
            // 
            this.textBoxTelefonNmr.Location = new System.Drawing.Point(477, 312);
            this.textBoxTelefonNmr.Name = "textBoxTelefonNmr";
            this.textBoxTelefonNmr.Size = new System.Drawing.Size(326, 22);
            this.textBoxTelefonNmr.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(407, 44);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Förnamn";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(398, 96);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Efternamn";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(363, 152);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Personnummer:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(410, 208);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(54, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "E-Post:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(413, 259);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(36, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "Lön:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(381, 317);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "Telefon Nmr:";
            // 
            // LäggTillLärareFormBtn
            // 
            this.LäggTillLärareFormBtn.Location = new System.Drawing.Point(544, 373);
            this.LäggTillLärareFormBtn.Name = "LäggTillLärareFormBtn";
            this.LäggTillLärareFormBtn.Size = new System.Drawing.Size(224, 47);
            this.LäggTillLärareFormBtn.TabIndex = 12;
            this.LäggTillLärareFormBtn.Text = "Lägg till";
            this.LäggTillLärareFormBtn.UseVisualStyleBackColor = true;
            this.LäggTillLärareFormBtn.Click += new System.EventHandler(this.LäggTillLärareFormBtn_Click);
            // 
            // AvbrytLärareFormBtn
            // 
            this.AvbrytLärareFormBtn.Location = new System.Drawing.Point(290, 373);
            this.AvbrytLärareFormBtn.Name = "AvbrytLärareFormBtn";
            this.AvbrytLärareFormBtn.Size = new System.Drawing.Size(199, 47);
            this.AvbrytLärareFormBtn.TabIndex = 13;
            this.AvbrytLärareFormBtn.Text = "Avbryt";
            this.AvbrytLärareFormBtn.UseVisualStyleBackColor = true;
            this.AvbrytLärareFormBtn.Click += new System.EventHandler(this.AvbrytLärareFormBtn_Click);
            // 
            // LärareForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(915, 451);
            this.Controls.Add(this.AvbrytLärareFormBtn);
            this.Controls.Add(this.LäggTillLärareFormBtn);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxTelefonNmr);
            this.Controls.Add(this.textBoxLön);
            this.Controls.Add(this.textBoxEPost);
            this.Controls.Add(this.textBoxPersonNmr);
            this.Controls.Add(this.textBoxEfterNamn);
            this.Controls.Add(this.textBoxFörNamn);
            this.Name = "LärareForm";
            this.Text = "LärareForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBoxFörNamn;
        private System.Windows.Forms.TextBox textBoxEfterNamn;
        private System.Windows.Forms.TextBox textBoxPersonNmr;
        private System.Windows.Forms.TextBox textBoxEPost;
        private System.Windows.Forms.TextBox textBoxLön;
        private System.Windows.Forms.TextBox textBoxTelefonNmr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button LäggTillLärareFormBtn;
        private System.Windows.Forms.Button AvbrytLärareFormBtn;
    }
}