﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class LäggTillKurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewLäggTillKurs = new System.Windows.Forms.DataGridView();
            this.LäggTillKursBtn = new System.Windows.Forms.Button();
            this.UppdateraLäggTillKursBtn = new System.Windows.Forms.Button();
            this.TillbakaLäggTillKursBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillKurs)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewLäggTillKurs
            // 
            this.dataGridViewLäggTillKurs.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewLäggTillKurs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewLäggTillKurs.Location = new System.Drawing.Point(222, 1);
            this.dataGridViewLäggTillKurs.Name = "dataGridViewLäggTillKurs";
            this.dataGridViewLäggTillKurs.RowHeadersWidth = 51;
            this.dataGridViewLäggTillKurs.RowTemplate.Height = 24;
            this.dataGridViewLäggTillKurs.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewLäggTillKurs.TabIndex = 0;
            // 
            // LäggTillKursBtn
            // 
            this.LäggTillKursBtn.Location = new System.Drawing.Point(4, 295);
            this.LäggTillKursBtn.Name = "LäggTillKursBtn";
            this.LäggTillKursBtn.Size = new System.Drawing.Size(217, 47);
            this.LäggTillKursBtn.TabIndex = 1;
            this.LäggTillKursBtn.Text = "Lägg till";
            this.LäggTillKursBtn.UseVisualStyleBackColor = true;
            this.LäggTillKursBtn.Click += new System.EventHandler(this.LäggTillKursBtn_Click);
            // 
            // UppdateraLäggTillKursBtn
            // 
            this.UppdateraLäggTillKursBtn.Location = new System.Drawing.Point(4, 348);
            this.UppdateraLäggTillKursBtn.Name = "UppdateraLäggTillKursBtn";
            this.UppdateraLäggTillKursBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraLäggTillKursBtn.TabIndex = 2;
            this.UppdateraLäggTillKursBtn.Text = "Uppdatera";
            this.UppdateraLäggTillKursBtn.UseVisualStyleBackColor = true;
            this.UppdateraLäggTillKursBtn.Click += new System.EventHandler(this.UppdateraLäggTillKursBtn_Click);
            // 
            // TillbakaLäggTillKursBtn
            // 
            this.TillbakaLäggTillKursBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaLäggTillKursBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaLäggTillKursBtn.Location = new System.Drawing.Point(0, 401);
            this.TillbakaLäggTillKursBtn.Name = "TillbakaLäggTillKursBtn";
            this.TillbakaLäggTillKursBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakaLäggTillKursBtn.TabIndex = 3;
            this.TillbakaLäggTillKursBtn.Text = "Tillbaka";
            this.TillbakaLäggTillKursBtn.UseVisualStyleBackColor = false;
            this.TillbakaLäggTillKursBtn.Click += new System.EventHandler(this.TillbakaLäggTillKursBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Lägg till data";
            // 
            // LäggTillKurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaLäggTillKursBtn);
            this.Controls.Add(this.UppdateraLäggTillKursBtn);
            this.Controls.Add(this.LäggTillKursBtn);
            this.Controls.Add(this.dataGridViewLäggTillKurs);
            this.Name = "LäggTillKurs";
            this.Text = "LäggTillKurs";
            this.Load += new System.EventHandler(this.LäggTillKurs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewLäggTillKurs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewLäggTillKurs;
        private System.Windows.Forms.Button LäggTillKursBtn;
        private System.Windows.Forms.Button UppdateraLäggTillKursBtn;
        private System.Windows.Forms.Button TillbakaLäggTillKursBtn;
        private System.Windows.Forms.Label label1;
    }
}