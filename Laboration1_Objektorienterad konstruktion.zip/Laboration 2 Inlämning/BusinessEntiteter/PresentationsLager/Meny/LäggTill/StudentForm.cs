﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class StudentForm : Form
    {
        private ServiceLager ServiceLager;
        public StudentForm(ServiceLager serviceLager)
        {
            InitializeComponent();
            ServiceLager = serviceLager;
        }

        private void LäggTillStudentFormBtn_Click(object sender, EventArgs e)
        {
            Student studentNy = new Student();

            studentNy.FörNamn = textBoxFörNamn.Text;
            studentNy.EfterNamn = textBoxEfterNamn.Text;
            studentNy.PersonNr = int.Parse(textBoxPersonNmr.Text);
            studentNy.Epost = textBoxEPost.Text;

            ServiceLager.LäggTillStudent(studentNy);

            this.Close();
        }

        private void AvbrytStudentFormBtn_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
