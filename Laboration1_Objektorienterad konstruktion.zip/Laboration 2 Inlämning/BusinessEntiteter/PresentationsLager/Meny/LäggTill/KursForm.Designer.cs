﻿
namespace PresentationsLager.Meny.LäggTill
{
    partial class KursForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LäggTillKursFormBtn = new System.Windows.Forms.Button();
            this.AvbrytLäggTillKursFormBtn = new System.Windows.Forms.Button();
            this.textBoxNamn = new System.Windows.Forms.TextBox();
            this.textBoxHp = new System.Windows.Forms.TextBox();
            this.textBoxStartDatum = new System.Windows.Forms.TextBox();
            this.textBoxSlutDatum = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // LäggTillKursFormBtn
            // 
            this.LäggTillKursFormBtn.BackColor = System.Drawing.Color.CornflowerBlue;
            this.LäggTillKursFormBtn.ForeColor = System.Drawing.Color.Cornsilk;
            this.LäggTillKursFormBtn.Location = new System.Drawing.Point(208, 210);
            this.LäggTillKursFormBtn.Name = "LäggTillKursFormBtn";
            this.LäggTillKursFormBtn.Size = new System.Drawing.Size(328, 39);
            this.LäggTillKursFormBtn.TabIndex = 0;
            this.LäggTillKursFormBtn.Text = "Lägg till";
            this.LäggTillKursFormBtn.UseVisualStyleBackColor = false;
            this.LäggTillKursFormBtn.Click += new System.EventHandler(this.LäggTillKursFormBtn_Click);
            // 
            // AvbrytLäggTillKursFormBtn
            // 
            this.AvbrytLäggTillKursFormBtn.BackColor = System.Drawing.Color.Black;
            this.AvbrytLäggTillKursFormBtn.ForeColor = System.Drawing.Color.White;
            this.AvbrytLäggTillKursFormBtn.Location = new System.Drawing.Point(24, 210);
            this.AvbrytLäggTillKursFormBtn.Name = "AvbrytLäggTillKursFormBtn";
            this.AvbrytLäggTillKursFormBtn.Size = new System.Drawing.Size(178, 39);
            this.AvbrytLäggTillKursFormBtn.TabIndex = 1;
            this.AvbrytLäggTillKursFormBtn.Text = "Avbryt";
            this.AvbrytLäggTillKursFormBtn.UseVisualStyleBackColor = false;
            this.AvbrytLäggTillKursFormBtn.Click += new System.EventHandler(this.AvbrytLäggTillKursFormBtn_Click);
            // 
            // textBoxNamn
            // 
            this.textBoxNamn.Location = new System.Drawing.Point(208, 83);
            this.textBoxNamn.Name = "textBoxNamn";
            this.textBoxNamn.Size = new System.Drawing.Size(328, 22);
            this.textBoxNamn.TabIndex = 2;
            // 
            // textBoxHp
            // 
            this.textBoxHp.Location = new System.Drawing.Point(208, 111);
            this.textBoxHp.Name = "textBoxHp";
            this.textBoxHp.Size = new System.Drawing.Size(328, 22);
            this.textBoxHp.TabIndex = 3;
            // 
            // textBoxStartDatum
            // 
            this.textBoxStartDatum.Location = new System.Drawing.Point(208, 138);
            this.textBoxStartDatum.Name = "textBoxStartDatum";
            this.textBoxStartDatum.Size = new System.Drawing.Size(328, 22);
            this.textBoxStartDatum.TabIndex = 4;
            // 
            // textBoxSlutDatum
            // 
            this.textBoxSlutDatum.Location = new System.Drawing.Point(208, 166);
            this.textBoxSlutDatum.Name = "textBoxSlutDatum";
            this.textBoxSlutDatum.Size = new System.Drawing.Size(328, 22);
            this.textBoxSlutDatum.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(21, 84);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 17);
            this.label1.TabIndex = 6;
            this.label1.Text = "Kurs namn:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(21, 111);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(123, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "Kursens Antal HP:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(21, 137);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(187, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "Start datum (YYYY-MM-DD):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(21, 169);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(181, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "Slut datum (YYYY-MM-DD):";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(19, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 29);
            this.label5.TabIndex = 10;
            this.label5.Text = "Lägg till kurs";
            // 
            // KursForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(561, 261);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxSlutDatum);
            this.Controls.Add(this.textBoxStartDatum);
            this.Controls.Add(this.textBoxHp);
            this.Controls.Add(this.textBoxNamn);
            this.Controls.Add(this.AvbrytLäggTillKursFormBtn);
            this.Controls.Add(this.LäggTillKursFormBtn);
            this.Name = "KursForm";
            this.Text = "KursForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button LäggTillKursFormBtn;
        private System.Windows.Forms.Button AvbrytLäggTillKursFormBtn;
        private System.Windows.Forms.TextBox textBoxNamn;
        private System.Windows.Forms.TextBox textBoxHp;
        private System.Windows.Forms.TextBox textBoxStartDatum;
        private System.Windows.Forms.TextBox textBoxSlutDatum;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
    }
}