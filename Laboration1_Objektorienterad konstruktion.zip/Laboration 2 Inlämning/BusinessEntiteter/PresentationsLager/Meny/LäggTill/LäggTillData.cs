﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class LäggTillData : Form
    {
        public LäggTillData()
        {
            InitializeComponent();
        }

        private void LäggTillStudentbtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillStudent läggTillStudent = new LäggTillStudent();
            läggTillStudent.Show();
        }

        private void LäggTillLärareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillLärare läggTillLärare = new LäggTillLärare();
            läggTillLärare.Show();
        }

        private void LäggTillKursBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillKurs läggTillKurs = new LäggTillKurs();
            läggTillKurs.Show();
        }

        private void LäggTillInstitutionBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillInstitution läggTillInstitution = new LäggTillInstitution();
            läggTillInstitution.Show();
        }

        private void TillbakaLäggTillDataBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            HuvudMeny huvudMeny = new HuvudMeny();
            huvudMeny.Show();
        }
    }
}
