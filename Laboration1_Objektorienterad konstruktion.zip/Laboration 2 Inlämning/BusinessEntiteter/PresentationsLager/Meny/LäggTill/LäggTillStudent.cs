﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.LäggTill
{
    public partial class LäggTillStudent : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public LäggTillStudent()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void LäggTillStudent_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillStudent();
        }

        private void UppdateraDataGridViewLäggTillStudent()
        {
            dataGridViewLäggTillStudent.DataSource = new BindingList<Student>(serviceLager.HämtaListaMedStudent());
        }

        private void UppdateraLäggTillStudentBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewLäggTillStudent();
        }

        private void TillbakaLäggTillStudentBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillData läggTillData = new LäggTillData();
            läggTillData.Show();
        }

        private void LäggTillStudentBtn_Click(object sender, EventArgs e)
        {
            StudentForm studentForm = new StudentForm(serviceLager);
            studentForm.Show();
        }
    }
}
