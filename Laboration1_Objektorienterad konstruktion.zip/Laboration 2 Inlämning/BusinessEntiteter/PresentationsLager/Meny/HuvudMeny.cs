﻿using PresentationsLager.Meny.Association;
using PresentationsLager.Meny.LäggTill;
using PresentationsLager.Meny.TaBort;
using PresentationsLager.Meny.Visa;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager
{
    public partial class HuvudMeny : Form
    {
        public HuvudMeny()
        {
            InitializeComponent();
        }

        private void VisaDataBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaData visaData = new VisaData();
            visaData.Show();
        }

        private void LäggTillBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LäggTillData läggTillData = new LäggTillData();
            läggTillData.Show();
        }

        private void TaBortBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortData taBortData = new TaBortData();
            taBortData.Show();
        }

        private void LoggaUtBtn_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void AssociationBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            AssociationLärareKurs associationLärareKurs = new AssociationLärareKurs();
            associationLärareKurs.Show();
        }
    }
}
