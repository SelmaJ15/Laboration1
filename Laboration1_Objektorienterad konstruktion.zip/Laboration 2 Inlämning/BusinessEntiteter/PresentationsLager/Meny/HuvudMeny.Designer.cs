﻿
namespace PresentationsLager
{
    partial class HuvudMeny
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.VisaDataBtn = new System.Windows.Forms.Button();
            this.LäggTillBtn = new System.Windows.Forms.Button();
            this.TaBortBtn = new System.Windows.Forms.Button();
            this.LoggaUtBtn = new System.Windows.Forms.Button();
            this.Huvudmenytext = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.AssociationBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // VisaDataBtn
            // 
            this.VisaDataBtn.BackColor = System.Drawing.Color.Coral;
            this.VisaDataBtn.ForeColor = System.Drawing.Color.White;
            this.VisaDataBtn.Location = new System.Drawing.Point(23, 104);
            this.VisaDataBtn.Name = "VisaDataBtn";
            this.VisaDataBtn.Size = new System.Drawing.Size(358, 49);
            this.VisaDataBtn.TabIndex = 0;
            this.VisaDataBtn.Text = "Visa Data";
            this.VisaDataBtn.UseVisualStyleBackColor = false;
            this.VisaDataBtn.Click += new System.EventHandler(this.VisaDataBtn_Click);
            // 
            // LäggTillBtn
            // 
            this.LäggTillBtn.Location = new System.Drawing.Point(23, 159);
            this.LäggTillBtn.Name = "LäggTillBtn";
            this.LäggTillBtn.Size = new System.Drawing.Size(358, 49);
            this.LäggTillBtn.TabIndex = 1;
            this.LäggTillBtn.Text = "Lägg till ";
            this.LäggTillBtn.UseVisualStyleBackColor = true;
            this.LäggTillBtn.Click += new System.EventHandler(this.LäggTillBtn_Click);
            // 
            // TaBortBtn
            // 
            this.TaBortBtn.Location = new System.Drawing.Point(23, 214);
            this.TaBortBtn.Name = "TaBortBtn";
            this.TaBortBtn.Size = new System.Drawing.Size(358, 49);
            this.TaBortBtn.TabIndex = 2;
            this.TaBortBtn.Text = "Ta Bort";
            this.TaBortBtn.UseVisualStyleBackColor = true;
            this.TaBortBtn.Click += new System.EventHandler(this.TaBortBtn_Click);
            // 
            // LoggaUtBtn
            // 
            this.LoggaUtBtn.BackColor = System.Drawing.Color.Black;
            this.LoggaUtBtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LoggaUtBtn.ForeColor = System.Drawing.Color.White;
            this.LoggaUtBtn.Location = new System.Drawing.Point(24, 324);
            this.LoggaUtBtn.Name = "LoggaUtBtn";
            this.LoggaUtBtn.Size = new System.Drawing.Size(358, 44);
            this.LoggaUtBtn.TabIndex = 3;
            this.LoggaUtBtn.Text = "Logga ut";
            this.LoggaUtBtn.UseVisualStyleBackColor = false;
            this.LoggaUtBtn.Click += new System.EventHandler(this.LoggaUtBtn_Click);
            // 
            // Huvudmenytext
            // 
            this.Huvudmenytext.AutoSize = true;
            this.Huvudmenytext.Font = new System.Drawing.Font("Microsoft YaHei", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Huvudmenytext.Location = new System.Drawing.Point(17, 22);
            this.Huvudmenytext.Name = "Huvudmenytext";
            this.Huvudmenytext.Size = new System.Drawing.Size(169, 33);
            this.Huvudmenytext.TabIndex = 4;
            this.Huvudmenytext.Text = "Huvudmeny";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 64);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(158, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Välkommen tillbaka!";
            // 
            // AssociationBtn
            // 
            this.AssociationBtn.Location = new System.Drawing.Point(23, 269);
            this.AssociationBtn.Name = "AssociationBtn";
            this.AssociationBtn.Size = new System.Drawing.Size(358, 49);
            this.AssociationBtn.TabIndex = 6;
            this.AssociationBtn.Text = "Associera";
            this.AssociationBtn.UseVisualStyleBackColor = true;
            this.AssociationBtn.Click += new System.EventHandler(this.AssociationBtn_Click);
            // 
            // HuvudMeny
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 403);
            this.Controls.Add(this.AssociationBtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Huvudmenytext);
            this.Controls.Add(this.LoggaUtBtn);
            this.Controls.Add(this.TaBortBtn);
            this.Controls.Add(this.LäggTillBtn);
            this.Controls.Add(this.VisaDataBtn);
            this.Name = "HuvudMeny";
            this.Text = "HuvudMeny";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button VisaDataBtn;
        private System.Windows.Forms.Button LäggTillBtn;
        private System.Windows.Forms.Button TaBortBtn;
        private System.Windows.Forms.Button LoggaUtBtn;
        private System.Windows.Forms.Label Huvudmenytext;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button AssociationBtn;
    }
}