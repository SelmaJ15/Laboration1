﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.TaBort
{
    public partial class TaBortStudent : Form
    {
        private ServiceLager serviceLager = new ServiceLager();
        private Student ValdStudent;
        public TaBortStudent()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void TaBortStudent_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortStudent();
        }

        private void UppdateraDataGridViewTaBortStudent()
        {
            dataGridViewTaBortStudent.DataSource = new BindingList<Student>(serviceLager.HämtaListaMedStudent());
        }

        private void TaBortStudentBtn_Click(object sender, EventArgs e)
        {
            if (ValdStudent != null)
            {
                serviceLager.TaBortStudent(ValdStudent);
            }
            UppdateraDataGridViewTaBortStudent();
        }

        private void UppdateraTaBortStudentBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortStudent();
        }

        private void dataGridViewTaBortStudent_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ValdStudent = dataGridViewTaBortStudent.SelectedRows[0].DataBoundItem as Student;
        }

        private void TillbakaTaBortStudent_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortData taBortData = new TaBortData();
            taBortData.Show();
        }
    }
}
