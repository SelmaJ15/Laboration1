﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.TaBort
{
    public partial class TaBortInstitution : Form
    {
        private ServiceLager serviceLager = new ServiceLager();
        private Institution ValdInstitution;
        public TaBortInstitution()
        {
            InitializeComponent();

            serviceLager.Seed();
        }

        private void dataGridViewTaBortInst_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TaBortInstitution_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortInst();
        }

        private void UppdateraDataGridViewTaBortInst()
        {
            dataGridViewTaBortInst.DataSource = new BindingList<Institution>(serviceLager.HämtaListaMedInstitution());
        }

        private void TaBortInstBtn_Click(object sender, EventArgs e)
        {
            if (ValdInstitution != null)
            {
                serviceLager.TaBortInstitution(ValdInstitution);
            }
            UppdateraDataGridViewTaBortInst();
        }

        private void dataGridViewTaBortInst_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ValdInstitution = dataGridViewTaBortInst.SelectedRows[0].DataBoundItem as Institution;
        }

        private void UppdateraTaBortInstBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortInst();
        }

        private void TillbakaTaBortInstBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortData taBortData = new TaBortData();
            taBortData.Show();
        }
    }
}
