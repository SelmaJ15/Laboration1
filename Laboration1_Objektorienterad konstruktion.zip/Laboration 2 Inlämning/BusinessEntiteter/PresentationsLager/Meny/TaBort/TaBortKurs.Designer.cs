﻿
namespace PresentationsLager.Meny.TaBort
{
    partial class TaBortKurs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewTaBortKurs = new System.Windows.Forms.DataGridView();
            this.TaBortKursBtn = new System.Windows.Forms.Button();
            this.UppdateraTaBortKursBtn = new System.Windows.Forms.Button();
            this.TillbakTaBortKursBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortKurs)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewTaBortKurs
            // 
            this.dataGridViewTaBortKurs.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewTaBortKurs.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTaBortKurs.Location = new System.Drawing.Point(223, 0);
            this.dataGridViewTaBortKurs.Name = "dataGridViewTaBortKurs";
            this.dataGridViewTaBortKurs.RowHeadersWidth = 51;
            this.dataGridViewTaBortKurs.RowTemplate.Height = 24;
            this.dataGridViewTaBortKurs.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewTaBortKurs.TabIndex = 0;
            this.dataGridViewTaBortKurs.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaBortKurs_CellClick);
            this.dataGridViewTaBortKurs.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaBortKurs_CellContentClick);
            // 
            // TaBortKursBtn
            // 
            this.TaBortKursBtn.Location = new System.Drawing.Point(4, 288);
            this.TaBortKursBtn.Name = "TaBortKursBtn";
            this.TaBortKursBtn.Size = new System.Drawing.Size(217, 47);
            this.TaBortKursBtn.TabIndex = 1;
            this.TaBortKursBtn.Text = "Ta Bort";
            this.TaBortKursBtn.UseVisualStyleBackColor = true;
            this.TaBortKursBtn.Click += new System.EventHandler(this.TaBortKursBtn_Click);
            // 
            // UppdateraTaBortKursBtn
            // 
            this.UppdateraTaBortKursBtn.Location = new System.Drawing.Point(4, 341);
            this.UppdateraTaBortKursBtn.Name = "UppdateraTaBortKursBtn";
            this.UppdateraTaBortKursBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraTaBortKursBtn.TabIndex = 2;
            this.UppdateraTaBortKursBtn.Text = "Uppdatera";
            this.UppdateraTaBortKursBtn.UseVisualStyleBackColor = true;
            this.UppdateraTaBortKursBtn.Click += new System.EventHandler(this.UppdateraTaBortKursBtn_Click);
            // 
            // TillbakTaBortKursBtn
            // 
            this.TillbakTaBortKursBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakTaBortKursBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakTaBortKursBtn.Location = new System.Drawing.Point(0, 401);
            this.TillbakTaBortKursBtn.Name = "TillbakTaBortKursBtn";
            this.TillbakTaBortKursBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakTaBortKursBtn.TabIndex = 3;
            this.TillbakTaBortKursBtn.Text = "Tillbaka";
            this.TillbakTaBortKursBtn.UseVisualStyleBackColor = false;
            this.TillbakTaBortKursBtn.Click += new System.EventHandler(this.TillbakTaBortKursBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ta bort data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(19, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Välj data för ta bort";
            // 
            // TaBortKurs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakTaBortKursBtn);
            this.Controls.Add(this.UppdateraTaBortKursBtn);
            this.Controls.Add(this.TaBortKursBtn);
            this.Controls.Add(this.dataGridViewTaBortKurs);
            this.Name = "TaBortKurs";
            this.Text = "TaBortKurs";
            this.Load += new System.EventHandler(this.TaBortKurs_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortKurs)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewTaBortKurs;
        private System.Windows.Forms.Button TaBortKursBtn;
        private System.Windows.Forms.Button UppdateraTaBortKursBtn;
        private System.Windows.Forms.Button TillbakTaBortKursBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}