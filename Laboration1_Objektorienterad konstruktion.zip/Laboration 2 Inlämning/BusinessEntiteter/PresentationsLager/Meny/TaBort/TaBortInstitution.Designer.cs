﻿
namespace PresentationsLager.Meny.TaBort
{
    partial class TaBortInstitution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewTaBortInst = new System.Windows.Forms.DataGridView();
            this.TaBortInstBtn = new System.Windows.Forms.Button();
            this.UppdateraTaBortInstBtn = new System.Windows.Forms.Button();
            this.TillbakaTaBortInstBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortInst)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewTaBortInst
            // 
            this.dataGridViewTaBortInst.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewTaBortInst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTaBortInst.Location = new System.Drawing.Point(223, -1);
            this.dataGridViewTaBortInst.Name = "dataGridViewTaBortInst";
            this.dataGridViewTaBortInst.RowHeadersWidth = 51;
            this.dataGridViewTaBortInst.RowTemplate.Height = 24;
            this.dataGridViewTaBortInst.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewTaBortInst.TabIndex = 0;
            this.dataGridViewTaBortInst.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaBortInst_CellClick);
            this.dataGridViewTaBortInst.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaBortInst_CellContentClick);
            // 
            // TaBortInstBtn
            // 
            this.TaBortInstBtn.Location = new System.Drawing.Point(3, 295);
            this.TaBortInstBtn.Name = "TaBortInstBtn";
            this.TaBortInstBtn.Size = new System.Drawing.Size(217, 47);
            this.TaBortInstBtn.TabIndex = 1;
            this.TaBortInstBtn.Text = "Ta Bort";
            this.TaBortInstBtn.UseVisualStyleBackColor = true;
            this.TaBortInstBtn.Click += new System.EventHandler(this.TaBortInstBtn_Click);
            // 
            // UppdateraTaBortInstBtn
            // 
            this.UppdateraTaBortInstBtn.Location = new System.Drawing.Point(3, 348);
            this.UppdateraTaBortInstBtn.Name = "UppdateraTaBortInstBtn";
            this.UppdateraTaBortInstBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraTaBortInstBtn.TabIndex = 2;
            this.UppdateraTaBortInstBtn.Text = "Uppdatera";
            this.UppdateraTaBortInstBtn.UseVisualStyleBackColor = true;
            this.UppdateraTaBortInstBtn.Click += new System.EventHandler(this.UppdateraTaBortInstBtn_Click);
            // 
            // TillbakaTaBortInstBtn
            // 
            this.TillbakaTaBortInstBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaTaBortInstBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaTaBortInstBtn.Location = new System.Drawing.Point(0, 400);
            this.TillbakaTaBortInstBtn.Name = "TillbakaTaBortInstBtn";
            this.TillbakaTaBortInstBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakaTaBortInstBtn.TabIndex = 3;
            this.TillbakaTaBortInstBtn.Text = "Tillbaka";
            this.TillbakaTaBortInstBtn.UseVisualStyleBackColor = false;
            this.TillbakaTaBortInstBtn.Click += new System.EventHandler(this.TillbakaTaBortInstBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ta bort data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Välj data för ta bort";
            // 
            // TaBortInstitution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaTaBortInstBtn);
            this.Controls.Add(this.UppdateraTaBortInstBtn);
            this.Controls.Add(this.TaBortInstBtn);
            this.Controls.Add(this.dataGridViewTaBortInst);
            this.Name = "TaBortInstitution";
            this.Text = "TaBortInstitution";
            this.Load += new System.EventHandler(this.TaBortInstitution_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortInst)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewTaBortInst;
        private System.Windows.Forms.Button TaBortInstBtn;
        private System.Windows.Forms.Button UppdateraTaBortInstBtn;
        private System.Windows.Forms.Button TillbakaTaBortInstBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}