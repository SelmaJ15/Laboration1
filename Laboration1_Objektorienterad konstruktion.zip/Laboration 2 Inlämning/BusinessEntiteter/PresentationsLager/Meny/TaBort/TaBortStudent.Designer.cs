﻿
namespace PresentationsLager.Meny.TaBort
{
    partial class TaBortStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewTaBortStudent = new System.Windows.Forms.DataGridView();
            this.TaBortStudentBtn = new System.Windows.Forms.Button();
            this.UppdateraTaBortStudentBtn = new System.Windows.Forms.Button();
            this.TillbakaTaBortStudent = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewTaBortStudent
            // 
            this.dataGridViewTaBortStudent.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewTaBortStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTaBortStudent.Location = new System.Drawing.Point(224, 3);
            this.dataGridViewTaBortStudent.Name = "dataGridViewTaBortStudent";
            this.dataGridViewTaBortStudent.RowHeadersWidth = 51;
            this.dataGridViewTaBortStudent.RowTemplate.Height = 24;
            this.dataGridViewTaBortStudent.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewTaBortStudent.TabIndex = 0;
            this.dataGridViewTaBortStudent.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaBortStudent_CellClick);
            // 
            // TaBortStudentBtn
            // 
            this.TaBortStudentBtn.Location = new System.Drawing.Point(4, 289);
            this.TaBortStudentBtn.Name = "TaBortStudentBtn";
            this.TaBortStudentBtn.Size = new System.Drawing.Size(217, 47);
            this.TaBortStudentBtn.TabIndex = 1;
            this.TaBortStudentBtn.Text = "Ta Bort";
            this.TaBortStudentBtn.UseVisualStyleBackColor = true;
            this.TaBortStudentBtn.Click += new System.EventHandler(this.TaBortStudentBtn_Click);
            // 
            // UppdateraTaBortStudentBtn
            // 
            this.UppdateraTaBortStudentBtn.Location = new System.Drawing.Point(4, 342);
            this.UppdateraTaBortStudentBtn.Name = "UppdateraTaBortStudentBtn";
            this.UppdateraTaBortStudentBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraTaBortStudentBtn.TabIndex = 2;
            this.UppdateraTaBortStudentBtn.Text = "Uppdatera";
            this.UppdateraTaBortStudentBtn.UseVisualStyleBackColor = true;
            this.UppdateraTaBortStudentBtn.Click += new System.EventHandler(this.UppdateraTaBortStudentBtn_Click);
            // 
            // TillbakaTaBortStudent
            // 
            this.TillbakaTaBortStudent.BackColor = System.Drawing.Color.Black;
            this.TillbakaTaBortStudent.ForeColor = System.Drawing.Color.White;
            this.TillbakaTaBortStudent.Location = new System.Drawing.Point(0, 399);
            this.TillbakaTaBortStudent.Name = "TillbakaTaBortStudent";
            this.TillbakaTaBortStudent.Size = new System.Drawing.Size(223, 48);
            this.TillbakaTaBortStudent.TabIndex = 3;
            this.TillbakaTaBortStudent.Text = "Tillbaka";
            this.TillbakaTaBortStudent.UseVisualStyleBackColor = false;
            this.TillbakaTaBortStudent.Click += new System.EventHandler(this.TillbakaTaBortStudent_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ta bort data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 71);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Välj data för ta bort";
            // 
            // TaBortStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaTaBortStudent);
            this.Controls.Add(this.UppdateraTaBortStudentBtn);
            this.Controls.Add(this.TaBortStudentBtn);
            this.Controls.Add(this.dataGridViewTaBortStudent);
            this.Name = "TaBortStudent";
            this.Text = "TaBortStudent";
            this.Load += new System.EventHandler(this.TaBortStudent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewTaBortStudent;
        private System.Windows.Forms.Button TaBortStudentBtn;
        private System.Windows.Forms.Button UppdateraTaBortStudentBtn;
        private System.Windows.Forms.Button TillbakaTaBortStudent;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}