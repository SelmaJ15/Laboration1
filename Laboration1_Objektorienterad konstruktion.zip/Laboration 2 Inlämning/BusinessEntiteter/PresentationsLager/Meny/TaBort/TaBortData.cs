﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.TaBort
{
    public partial class TaBortData : Form
    {
        public TaBortData()
        {
            InitializeComponent();
        }

        private void TaBortStudentBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortStudent taBortStudent = new TaBortStudent();
            taBortStudent.Show();
        }

        private void TaBortLärareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortLärare taBortLärare = new TaBortLärare();
            taBortLärare.Show();
        }

        private void TaBortKursBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortKurs taBortKurs = new TaBortKurs();
            taBortKurs.Show();
        }

        private void TaBortInstBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortInstitution taBortInstitution = new TaBortInstitution();
            taBortInstitution.Show();
        }

        private void TillbakaTaBortDataBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            HuvudMeny huvudMeny = new HuvudMeny();
            huvudMeny.Show();
        }
    }
}
