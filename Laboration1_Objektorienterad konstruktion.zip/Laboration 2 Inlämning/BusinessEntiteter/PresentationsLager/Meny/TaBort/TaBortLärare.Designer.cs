﻿
namespace PresentationsLager.Meny.TaBort
{
    partial class TaBortLärare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewTaBortLärare = new System.Windows.Forms.DataGridView();
            this.TaBortLärareBtn = new System.Windows.Forms.Button();
            this.UppdateraTaBortLärareBtn = new System.Windows.Forms.Button();
            this.TillbakaTaBortLärareBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortLärare)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewTaBortLärare
            // 
            this.dataGridViewTaBortLärare.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewTaBortLärare.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewTaBortLärare.Location = new System.Drawing.Point(223, 0);
            this.dataGridViewTaBortLärare.Name = "dataGridViewTaBortLärare";
            this.dataGridViewTaBortLärare.RowHeadersWidth = 51;
            this.dataGridViewTaBortLärare.RowTemplate.Height = 24;
            this.dataGridViewTaBortLärare.Size = new System.Drawing.Size(576, 448);
            this.dataGridViewTaBortLärare.TabIndex = 0;
            this.dataGridViewTaBortLärare.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewTaBortLärare_CellClick);
            // 
            // TaBortLärareBtn
            // 
            this.TaBortLärareBtn.Location = new System.Drawing.Point(4, 291);
            this.TaBortLärareBtn.Name = "TaBortLärareBtn";
            this.TaBortLärareBtn.Size = new System.Drawing.Size(217, 47);
            this.TaBortLärareBtn.TabIndex = 1;
            this.TaBortLärareBtn.Text = "Ta Bort";
            this.TaBortLärareBtn.UseVisualStyleBackColor = true;
            this.TaBortLärareBtn.Click += new System.EventHandler(this.TaBortLärareBtn_Click);
            // 
            // UppdateraTaBortLärareBtn
            // 
            this.UppdateraTaBortLärareBtn.Location = new System.Drawing.Point(4, 344);
            this.UppdateraTaBortLärareBtn.Name = "UppdateraTaBortLärareBtn";
            this.UppdateraTaBortLärareBtn.Size = new System.Drawing.Size(217, 47);
            this.UppdateraTaBortLärareBtn.TabIndex = 2;
            this.UppdateraTaBortLärareBtn.Text = "Uppdatera";
            this.UppdateraTaBortLärareBtn.UseVisualStyleBackColor = true;
            this.UppdateraTaBortLärareBtn.Click += new System.EventHandler(this.UppdateraTaBortLärareBtn_Click);
            // 
            // TillbakaTaBortLärareBtn
            // 
            this.TillbakaTaBortLärareBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaTaBortLärareBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaTaBortLärareBtn.Location = new System.Drawing.Point(0, 397);
            this.TillbakaTaBortLärareBtn.Name = "TillbakaTaBortLärareBtn";
            this.TillbakaTaBortLärareBtn.Size = new System.Drawing.Size(223, 48);
            this.TillbakaTaBortLärareBtn.TabIndex = 3;
            this.TillbakaTaBortLärareBtn.Text = "Tillbaka";
            this.TillbakaTaBortLärareBtn.UseVisualStyleBackColor = false;
            this.TillbakaTaBortLärareBtn.Click += new System.EventHandler(this.TillbakaTaBortLärareBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(160, 29);
            this.label1.TabIndex = 4;
            this.label1.Text = "Ta bort data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(18, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(152, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "Välj data för ta bort";
            // 
            // TaBortLärare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaTaBortLärareBtn);
            this.Controls.Add(this.UppdateraTaBortLärareBtn);
            this.Controls.Add(this.TaBortLärareBtn);
            this.Controls.Add(this.dataGridViewTaBortLärare);
            this.Name = "TaBortLärare";
            this.Text = "TaBortLärare";
            this.Load += new System.EventHandler(this.TaBortLärare_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTaBortLärare)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewTaBortLärare;
        private System.Windows.Forms.Button TaBortLärareBtn;
        private System.Windows.Forms.Button UppdateraTaBortLärareBtn;
        private System.Windows.Forms.Button TillbakaTaBortLärareBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}