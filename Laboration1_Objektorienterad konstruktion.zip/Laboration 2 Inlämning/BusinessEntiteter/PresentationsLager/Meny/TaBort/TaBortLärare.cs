﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.TaBort
{
    public partial class TaBortLärare : Form
    {
        private ServiceLager serviceLager = new ServiceLager();
        private Lärare ValdLärare;
        public TaBortLärare()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void TaBortLärare_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortLärare();
        }

        private void UppdateraDataGridViewTaBortLärare()
        {
            dataGridViewTaBortLärare.DataSource = new BindingList<Lärare>(serviceLager.HämtaListaMedLärare());
        }

        private void UppdateraTaBortLärareBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortLärare();
        }

        private void dataGridViewTaBortLärare_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ValdLärare = dataGridViewTaBortLärare.SelectedRows[0].DataBoundItem as Lärare;
        }

        private void TillbakaTaBortLärareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortData taBortData = new TaBortData();
            taBortData.Show();
        }

        private void TaBortLärareBtn_Click(object sender, EventArgs e)
        {
            if (ValdLärare != null)
            {
                serviceLager.TaBortLärare(ValdLärare);
            }
            UppdateraDataGridViewTaBortLärare();
        }
    }
}
