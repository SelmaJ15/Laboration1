﻿
namespace PresentationsLager.Meny.TaBort
{
    partial class TaBortData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TaBortStudentBtn = new System.Windows.Forms.Button();
            this.TaBortLärareBtn = new System.Windows.Forms.Button();
            this.TaBortKursBtn = new System.Windows.Forms.Button();
            this.TaBortInstBtn = new System.Windows.Forms.Button();
            this.TillbakaTaBortDataBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // TaBortStudentBtn
            // 
            this.TaBortStudentBtn.Location = new System.Drawing.Point(12, 195);
            this.TaBortStudentBtn.Name = "TaBortStudentBtn";
            this.TaBortStudentBtn.Size = new System.Drawing.Size(382, 46);
            this.TaBortStudentBtn.TabIndex = 0;
            this.TaBortStudentBtn.Text = "Student";
            this.TaBortStudentBtn.UseVisualStyleBackColor = true;
            this.TaBortStudentBtn.Click += new System.EventHandler(this.TaBortStudentBtn_Click);
            // 
            // TaBortLärareBtn
            // 
            this.TaBortLärareBtn.Location = new System.Drawing.Point(12, 247);
            this.TaBortLärareBtn.Name = "TaBortLärareBtn";
            this.TaBortLärareBtn.Size = new System.Drawing.Size(382, 42);
            this.TaBortLärareBtn.TabIndex = 1;
            this.TaBortLärareBtn.Text = "Lärare";
            this.TaBortLärareBtn.UseVisualStyleBackColor = true;
            this.TaBortLärareBtn.Click += new System.EventHandler(this.TaBortLärareBtn_Click);
            // 
            // TaBortKursBtn
            // 
            this.TaBortKursBtn.Location = new System.Drawing.Point(12, 102);
            this.TaBortKursBtn.Name = "TaBortKursBtn";
            this.TaBortKursBtn.Size = new System.Drawing.Size(382, 40);
            this.TaBortKursBtn.TabIndex = 2;
            this.TaBortKursBtn.Text = "Kurs";
            this.TaBortKursBtn.UseVisualStyleBackColor = true;
            this.TaBortKursBtn.Click += new System.EventHandler(this.TaBortKursBtn_Click);
            // 
            // TaBortInstBtn
            // 
            this.TaBortInstBtn.Location = new System.Drawing.Point(12, 148);
            this.TaBortInstBtn.Name = "TaBortInstBtn";
            this.TaBortInstBtn.Size = new System.Drawing.Size(382, 41);
            this.TaBortInstBtn.TabIndex = 3;
            this.TaBortInstBtn.Text = "Institution";
            this.TaBortInstBtn.UseVisualStyleBackColor = true;
            this.TaBortInstBtn.Click += new System.EventHandler(this.TaBortInstBtn_Click);
            // 
            // TillbakaTaBortDataBtn
            // 
            this.TillbakaTaBortDataBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaTaBortDataBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaTaBortDataBtn.Location = new System.Drawing.Point(12, 312);
            this.TillbakaTaBortDataBtn.Name = "TillbakaTaBortDataBtn";
            this.TillbakaTaBortDataBtn.Size = new System.Drawing.Size(382, 51);
            this.TillbakaTaBortDataBtn.TabIndex = 4;
            this.TillbakaTaBortDataBtn.Text = "Tillbaka";
            this.TillbakaTaBortDataBtn.UseVisualStyleBackColor = false;
            this.TillbakaTaBortDataBtn.Click += new System.EventHandler(this.TillbakaTaBortDataBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(148, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Ta bort data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(16, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(219, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Välj vad du vill ta bort nedan";
            // 
            // TaBortData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 370);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaTaBortDataBtn);
            this.Controls.Add(this.TaBortInstBtn);
            this.Controls.Add(this.TaBortKursBtn);
            this.Controls.Add(this.TaBortLärareBtn);
            this.Controls.Add(this.TaBortStudentBtn);
            this.Name = "TaBortData";
            this.Text = "TaBortData";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button TaBortStudentBtn;
        private System.Windows.Forms.Button TaBortLärareBtn;
        private System.Windows.Forms.Button TaBortKursBtn;
        private System.Windows.Forms.Button TaBortInstBtn;
        private System.Windows.Forms.Button TillbakaTaBortDataBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}