﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.TaBort
{
    public partial class TaBortKurs : Form
    {
        private ServiceLager serviceLager = new ServiceLager();
        private Kurs ValdKurs;
        public TaBortKurs()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void dataGridViewTaBortKurs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void TaBortKurs_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortKurs();
        }

        private void UppdateraDataGridViewTaBortKurs()
        {
            dataGridViewTaBortKurs.DataSource = new BindingList<Kurs>(serviceLager.HämtaListaMedKurs());
        }

        private void TaBortKursBtn_Click(object sender, EventArgs e)
        {
            if ( ValdKurs != null)
            {
                serviceLager.TaBortKurs(ValdKurs);
            }
            UppdateraDataGridViewTaBortKurs();
        }

        private void UppdateraTaBortKursBtn_Click(object sender, EventArgs e)
        {
            UppdateraDataGridViewTaBortKurs();
        }

        private void dataGridViewTaBortKurs_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            ValdKurs = dataGridViewTaBortKurs.SelectedRows[0].DataBoundItem as Kurs;
        }

        private void TillbakTaBortKursBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            TaBortData taBortData = new TaBortData();
            taBortData.Show();
        }
    }
}
