﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.Visa
{
    public partial class VisaLärare : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public VisaLärare()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void VisaLärare_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewVisaLärare();
        }

        private void UppdateraDataGridViewVisaLärare()
        {
            dataGridViewVisaLärare.DataSource = new BindingList<Lärare>(serviceLager.HämtaListaMedLärare());
        }

        private void TillbakaVisaLärareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaData visaData = new VisaData();
            visaData.Show();
        }
    }
}
