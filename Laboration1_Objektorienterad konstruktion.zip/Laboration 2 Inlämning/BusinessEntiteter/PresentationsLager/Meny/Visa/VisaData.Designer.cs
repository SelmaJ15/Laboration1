﻿
namespace PresentationsLager.Meny.Visa
{
    partial class VisaData
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.VisaDataLärareBtn = new System.Windows.Forms.Button();
            this.VisaDataStudentBtn = new System.Windows.Forms.Button();
            this.VisaDataKursBtn = new System.Windows.Forms.Button();
            this.VisaDataInstBtn = new System.Windows.Forms.Button();
            this.TillbakaVisaDataBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // VisaDataLärareBtn
            // 
            this.VisaDataLärareBtn.Location = new System.Drawing.Point(27, 146);
            this.VisaDataLärareBtn.Name = "VisaDataLärareBtn";
            this.VisaDataLärareBtn.Size = new System.Drawing.Size(358, 51);
            this.VisaDataLärareBtn.TabIndex = 0;
            this.VisaDataLärareBtn.Text = "Lärare";
            this.VisaDataLärareBtn.UseVisualStyleBackColor = true;
            this.VisaDataLärareBtn.Click += new System.EventHandler(this.VisaDataLärareBtn_Click);
            // 
            // VisaDataStudentBtn
            // 
            this.VisaDataStudentBtn.Location = new System.Drawing.Point(27, 90);
            this.VisaDataStudentBtn.Name = "VisaDataStudentBtn";
            this.VisaDataStudentBtn.Size = new System.Drawing.Size(358, 50);
            this.VisaDataStudentBtn.TabIndex = 1;
            this.VisaDataStudentBtn.Text = "Student";
            this.VisaDataStudentBtn.UseVisualStyleBackColor = true;
            this.VisaDataStudentBtn.Click += new System.EventHandler(this.VisaDataStudentBtn_Click);
            // 
            // VisaDataKursBtn
            // 
            this.VisaDataKursBtn.Location = new System.Drawing.Point(27, 203);
            this.VisaDataKursBtn.Name = "VisaDataKursBtn";
            this.VisaDataKursBtn.Size = new System.Drawing.Size(358, 49);
            this.VisaDataKursBtn.TabIndex = 2;
            this.VisaDataKursBtn.Text = "Kurs";
            this.VisaDataKursBtn.UseVisualStyleBackColor = true;
            this.VisaDataKursBtn.Click += new System.EventHandler(this.VisaDataKursBtn_Click);
            // 
            // VisaDataInstBtn
            // 
            this.VisaDataInstBtn.Location = new System.Drawing.Point(27, 258);
            this.VisaDataInstBtn.Name = "VisaDataInstBtn";
            this.VisaDataInstBtn.Size = new System.Drawing.Size(358, 50);
            this.VisaDataInstBtn.TabIndex = 3;
            this.VisaDataInstBtn.Text = "Institution";
            this.VisaDataInstBtn.UseVisualStyleBackColor = true;
            this.VisaDataInstBtn.Click += new System.EventHandler(this.VisaDataInstBtn_Click);
            // 
            // TillbakaVisaDataBtn
            // 
            this.TillbakaVisaDataBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaVisaDataBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaVisaDataBtn.Location = new System.Drawing.Point(27, 314);
            this.TillbakaVisaDataBtn.Name = "TillbakaVisaDataBtn";
            this.TillbakaVisaDataBtn.Size = new System.Drawing.Size(358, 44);
            this.TillbakaVisaDataBtn.TabIndex = 4;
            this.TillbakaVisaDataBtn.Text = "Tillbaka";
            this.TillbakaVisaDataBtn.UseVisualStyleBackColor = false;
            this.TillbakaVisaDataBtn.Click += new System.EventHandler(this.TillbakaVisaDataBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 21);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 29);
            this.label1.TabIndex = 5;
            this.label1.Text = "Visa data";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(26, 59);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(139, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Välj vad du vill se";
            // 
            // VisaData
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(406, 377);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaVisaDataBtn);
            this.Controls.Add(this.VisaDataInstBtn);
            this.Controls.Add(this.VisaDataKursBtn);
            this.Controls.Add(this.VisaDataStudentBtn);
            this.Controls.Add(this.VisaDataLärareBtn);
            this.Name = "VisaData";
            this.Text = "VisaData";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button VisaDataLärareBtn;
        private System.Windows.Forms.Button VisaDataStudentBtn;
        private System.Windows.Forms.Button VisaDataKursBtn;
        private System.Windows.Forms.Button VisaDataInstBtn;
        private System.Windows.Forms.Button TillbakaVisaDataBtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}