﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.Visa
{
    public partial class VisaKurs : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public VisaKurs()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void TillbakaVisaKursBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaData visaData = new VisaData();
            visaData.Show();
        }

        private void VisaKurs_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewVisaKurs();
        }

        private void UppdateraDataGridViewVisaKurs()
        {
            dataGridViewVisaKurs.DataSource = new BindingList<Kurs>(serviceLager.HämtaListaMedKurs());
        }
    }
}
