﻿
namespace PresentationsLager.Meny.Visa
{
    partial class VisaInstitution
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewVisaInst = new System.Windows.Forms.DataGridView();
            this.TillbakaVisaInstBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisaInst)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewVisaInst
            // 
            this.dataGridViewVisaInst.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewVisaInst.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVisaInst.Location = new System.Drawing.Point(208, 2);
            this.dataGridViewVisaInst.Name = "dataGridViewVisaInst";
            this.dataGridViewVisaInst.RowHeadersWidth = 51;
            this.dataGridViewVisaInst.RowTemplate.Height = 24;
            this.dataGridViewVisaInst.Size = new System.Drawing.Size(635, 449);
            this.dataGridViewVisaInst.TabIndex = 0;
            // 
            // TillbakaVisaInstBtn
            // 
            this.TillbakaVisaInstBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaVisaInstBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaVisaInstBtn.Location = new System.Drawing.Point(0, 404);
            this.TillbakaVisaInstBtn.Name = "TillbakaVisaInstBtn";
            this.TillbakaVisaInstBtn.Size = new System.Drawing.Size(208, 47);
            this.TillbakaVisaInstBtn.TabIndex = 1;
            this.TillbakaVisaInstBtn.Text = "Tillbaka";
            this.TillbakaVisaInstBtn.UseVisualStyleBackColor = false;
            this.TillbakaVisaInstBtn.Click += new System.EventHandler(this.TillbakaVisaInstBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(31, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(156, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Institutioner";
            // 
            // VisaInstitution
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(843, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaVisaInstBtn);
            this.Controls.Add(this.dataGridViewVisaInst);
            this.Name = "VisaInstitution";
            this.Text = "VisaInstitution";
            this.Load += new System.EventHandler(this.VisaInstitution_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisaInst)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewVisaInst;
        private System.Windows.Forms.Button TillbakaVisaInstBtn;
        private System.Windows.Forms.Label label1;
    }
}