﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.Visa
{
    public partial class VisaInstitution : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public VisaInstitution()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void VisaInstitution_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewVisaInst();
        }

        private void UppdateraDataGridViewVisaInst()
        {
            dataGridViewVisaInst.DataSource = new BindingList<Institution>(serviceLager.HämtaListaMedInstitution());
        }

        private void TillbakaVisaInstBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaData visaData = new VisaData();
            visaData.Show();
        }

    }
}
