﻿using BusinessEntiteter;
using DataLager;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.Visa
{
    public partial class VisaStudent : Form
    {
        ServiceLager serviceLager = new ServiceLager();
        public VisaStudent()
        {
            InitializeComponent();
            serviceLager.Seed();
        }

        private void VisaStudent_Load(object sender, EventArgs e)
        {
            UppdateraDataGridViewVisaStudent();
        }

        private void UppdateraDataGridViewVisaStudent()
        {
            dataGridViewVisaStudent.DataSource = new BindingList<Student>(serviceLager.HämtaListaMedStudent());
        }

        private void TillbakaVisaStudentBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaData visaData = new VisaData();
            visaData.Show();
        }
    }
}
