﻿
namespace PresentationsLager.Meny.Visa
{
    partial class VisaLärare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewVisaLärare = new System.Windows.Forms.DataGridView();
            this.TillbakaVisaLärareBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisaLärare)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewVisaLärare
            // 
            this.dataGridViewVisaLärare.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewVisaLärare.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVisaLärare.Location = new System.Drawing.Point(207, 1);
            this.dataGridViewVisaLärare.Name = "dataGridViewVisaLärare";
            this.dataGridViewVisaLärare.RowHeadersWidth = 51;
            this.dataGridViewVisaLärare.RowTemplate.Height = 24;
            this.dataGridViewVisaLärare.Size = new System.Drawing.Size(635, 449);
            this.dataGridViewVisaLärare.TabIndex = 0;
            // 
            // TillbakaVisaLärareBtn
            // 
            this.TillbakaVisaLärareBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaVisaLärareBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaVisaLärareBtn.Location = new System.Drawing.Point(-1, 402);
            this.TillbakaVisaLärareBtn.Name = "TillbakaVisaLärareBtn";
            this.TillbakaVisaLärareBtn.Size = new System.Drawing.Size(208, 47);
            this.TillbakaVisaLärareBtn.TabIndex = 1;
            this.TillbakaVisaLärareBtn.Text = "Tillbaka";
            this.TillbakaVisaLärareBtn.UseVisualStyleBackColor = false;
            this.TillbakaVisaLärareBtn.Click += new System.EventHandler(this.TillbakaVisaLärareBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(53, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Lärare";
            // 
            // VisaLärare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(843, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaVisaLärareBtn);
            this.Controls.Add(this.dataGridViewVisaLärare);
            this.Name = "VisaLärare";
            this.Text = "VisaLärare";
            this.Load += new System.EventHandler(this.VisaLärare_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisaLärare)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewVisaLärare;
        private System.Windows.Forms.Button TillbakaVisaLärareBtn;
        private System.Windows.Forms.Label label1;
    }
}