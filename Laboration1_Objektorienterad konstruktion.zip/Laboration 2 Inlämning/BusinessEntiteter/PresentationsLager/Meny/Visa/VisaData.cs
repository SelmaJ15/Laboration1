﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PresentationsLager.Meny.Visa
{
    public partial class VisaData : Form
    {
        public VisaData()
        {
            InitializeComponent();
        }

        private void VisaDataLärareBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaLärare visaLärare = new VisaLärare();
            visaLärare.Show();
        }

        private void VisaDataStudentBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaStudent visaStudent = new VisaStudent();
            visaStudent.Show();
        }

        private void VisaDataKursBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaKurs visaKurs = new VisaKurs();
            visaKurs.Show();
        }

        private void VisaDataInstBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            VisaInstitution visaInstitution = new VisaInstitution();
            visaInstitution.Show();
        }

        private void TillbakaVisaDataBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            HuvudMeny huvudMeny = new HuvudMeny();
            huvudMeny.Show();
        }
    }
}
