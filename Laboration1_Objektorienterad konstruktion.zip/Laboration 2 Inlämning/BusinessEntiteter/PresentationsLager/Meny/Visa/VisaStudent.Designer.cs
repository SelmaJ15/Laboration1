﻿
namespace PresentationsLager.Meny.Visa
{
    partial class VisaStudent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewVisaStudent = new System.Windows.Forms.DataGridView();
            this.TillbakaVisaStudentBtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisaStudent)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewVisaStudent
            // 
            this.dataGridViewVisaStudent.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewVisaStudent.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVisaStudent.Location = new System.Drawing.Point(208, 1);
            this.dataGridViewVisaStudent.Name = "dataGridViewVisaStudent";
            this.dataGridViewVisaStudent.RowHeadersWidth = 51;
            this.dataGridViewVisaStudent.RowTemplate.Height = 24;
            this.dataGridViewVisaStudent.Size = new System.Drawing.Size(635, 449);
            this.dataGridViewVisaStudent.TabIndex = 0;
            // 
            // TillbakaVisaStudentBtn
            // 
            this.TillbakaVisaStudentBtn.BackColor = System.Drawing.Color.Black;
            this.TillbakaVisaStudentBtn.FlatAppearance.BorderSize = 0;
            this.TillbakaVisaStudentBtn.ForeColor = System.Drawing.Color.White;
            this.TillbakaVisaStudentBtn.Location = new System.Drawing.Point(0, 403);
            this.TillbakaVisaStudentBtn.Name = "TillbakaVisaStudentBtn";
            this.TillbakaVisaStudentBtn.Size = new System.Drawing.Size(208, 47);
            this.TillbakaVisaStudentBtn.TabIndex = 1;
            this.TillbakaVisaStudentBtn.Text = "Tillbaka";
            this.TillbakaVisaStudentBtn.UseVisualStyleBackColor = false;
            this.TillbakaVisaStudentBtn.Click += new System.EventHandler(this.TillbakaVisaStudentBtn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(37, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(131, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Studenter";
            // 
            // VisaStudent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Coral;
            this.ClientSize = new System.Drawing.Size(843, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.TillbakaVisaStudentBtn);
            this.Controls.Add(this.dataGridViewVisaStudent);
            this.ForeColor = System.Drawing.Color.Black;
            this.Name = "VisaStudent";
            this.ShowIcon = false;
            this.Text = "VisaStudent";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.VisaStudent_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVisaStudent)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewVisaStudent;
        private System.Windows.Forms.Button TillbakaVisaStudentBtn;
        private System.Windows.Forms.Label label1;
    }
}