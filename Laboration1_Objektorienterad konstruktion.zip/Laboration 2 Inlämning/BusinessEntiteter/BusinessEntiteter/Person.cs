﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntiteter
{
    public abstract class Person
    {

        public virtual string FörNamn { get; set; }
        public virtual string EfterNamn { get; set; }
        public virtual int PersonNr { get; set; }
        public virtual string Epost { get; set; }
        public Person(string förnamn, string efternamn, int personnr, string epost)
        {
            FörNamn = förnamn;
            EfterNamn = efternamn;
            PersonNr = personnr;
            Epost = epost;
        }
        public Person()
        {

        }
    }
}
