﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntiteter
{
    public class Kurs
    {
        public string Namn { get; set; }
        public int Högskolepoäng { get; set; }
        public int KursID { get; set; }
        public string StartDatum { get; set; }
        public string SlutDatum { get; set; }
        public List<Kurs> Kurser { get; set; }
        public List<Lärare> Undervisare { get; set; }
        public List<Institution> Institutioner { get; set; }

        public Kurs(int kursID, string namn, int högskolepoäng, string startDatum, string slutDatum)
        {
            KursID = kursID;
            Namn = namn;
            Högskolepoäng = högskolepoäng;
            StartDatum = startDatum;
            SlutDatum = slutDatum;
            Undervisare = new List<Lärare>();
            Institutioner = new List<Institution>();
            Kurser = new List<Kurs>();
        }

        public Kurs()
        {

        }
    }
}
