﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntiteter
{
    public class Student : Person
    {
        public override string FörNamn { get; set; }
        public override string EfterNamn { get; set; }
        public override int PersonNr { get; set; }
        public override string Epost { get; set; }
        public int StudentID { get; set; }
        public Student(int personnr, int studentID, string förnamn, string efternamn, string epost)
            : base(förnamn, efternamn, personnr, epost)
        {
            StudentID = studentID;
        }
        public Student()
        {

        }
    }
}
