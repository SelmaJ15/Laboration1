﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntiteter
{
    public class Lärare : Person
    {
        public override string FörNamn { get; set; }
        public override string EfterNamn { get; set; }
        public override int PersonNr { get; set; }
        public override string Epost { get; set; }
        public int TelefonNmr { get; set; }
        public int Signatur { get; set; }
        public int Lön { get; set; }
        public List<Institution> Institutioner { get; set; }
        public List<Kurs> Kurser { get; set; }


        public Lärare(int personnr, string förnamn, string efternamn, int signatur, string epost, int lön, int telefonNr)
            : base(förnamn, efternamn, personnr, epost)
        {
            TelefonNmr = telefonNr;
            Signatur = signatur;
            Lön = lön;
            Institutioner = new List<Institution>();
            Kurser = new List<Kurs>();
        }
        public Lärare()
        {

        }

    }
}
