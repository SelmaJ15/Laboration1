﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BusinessEntiteter
{
    public class Institution
    {
        public string Namn { get; set; }
        public string Prefekt { get; set; }
        public int InstID { get; set; }
        public Institution(string namn, string prefekt, int instID)
        {
            Namn = namn;
            Prefekt = prefekt;
            InstID = instID;
        }

        public Institution()
        {

        }
    }
}
