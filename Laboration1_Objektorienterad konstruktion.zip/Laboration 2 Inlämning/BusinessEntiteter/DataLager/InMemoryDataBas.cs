﻿using BusinessEntiteter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLager
{
    class InMemoryDatabas
    {
        internal List<Lärare> lärare = new List<Lärare>();
        internal List<Student> studenter = new List<Student>();
        internal List<Institution> institutioner = new List<Institution>();
        internal List<Kurs> kurser = new List<Kurs>();

        private static int unikStudentID = 1;
        private static int unikSignatur = 1;
        private static int unikInstID = 1;
        private static int unikKursID = 1;

        internal void Seed()
        {
            #region Student1
            Student student1 = new Student();
            student1.StudentID = unikStudentID++;
            student1.FörNamn = "Adam";
            student1.EfterNamn = "Adamsson";
            student1.PersonNr = 20020902;
            student1.Epost = "adam@student.hb.se";

            studenter.Add(student1);
            #endregion

            #region student2
            Student student2 = new Student();
            student2.StudentID = unikStudentID++;
            student2.FörNamn = "Bert";
            student2.EfterNamn = "Bertsson";
            student2.PersonNr = 20030623;
            student2.Epost = "bert@student.hb.se";

            studenter.Add(student2);
            #endregion

            #region lärare1
            Lärare lärare1 = new Lärare();
            lärare1.Signatur = unikSignatur++;
            lärare1.FörNamn = "Kalle";
            lärare1.EfterNamn = "Kallesson";
            lärare1.PersonNr = 19990712;
            lärare1.Epost = "Kalle@hb.se";
            lärare1.Lön = 30000;
            lärare1.TelefonNmr = 1233275388;

            lärare.Add(lärare1);
            #endregion

            #region lärare2
            Lärare lärare2 = new Lärare();
            lärare2.Signatur = unikSignatur++;
            lärare2.FörNamn = "Carl";
            lärare2.EfterNamn = "Carlsson";
            lärare2.PersonNr = 19340124;
            lärare2.Epost = "Carl@hb.se";
            lärare2.Lön = 33000;
            lärare2.TelefonNmr = 1274375388;

            lärare.Add(lärare2);
            #endregion

            #region kurs1
            Kurs kurs1 = new Kurs();
            kurs1.KursID = unikKursID++;
            kurs1.Namn = "Programmering Prop";
            kurs1.Högskolepoäng = 14;
            kurs1.StartDatum = "0001-01-01";
            kurs1.SlutDatum = "0001-01-02";

            kurser.Add(kurs1);

            #endregion

            #region kurs2
            Kurs kurs2 = new Kurs();
            kurs2.KursID = unikKursID++;
            kurs2.Namn = "Dataanalys Klok";
            kurs2.Högskolepoäng = 11;
            kurs2.StartDatum = "0002-02-02";
            kurs2.SlutDatum = "0002-02-03";

            kurser.Add(kurs2);

            #endregion

            #region kurs3
            Kurs kurs3 = new Kurs();
            kurs3.KursID = unikKursID++;
            kurs3.Namn = "Instansering av skor";
            kurs3.Högskolepoäng = 7;
            kurs3.StartDatum = "0003-03-03";
            kurs3.SlutDatum = "0003-03-04";

            kurser.Add(kurs3);
            #endregion

            #region institution1
            Institution institution1 = new Institution();
            institution1.InstID = unikInstID++;
            institution1.Namn = "Alikante 3";
            institution1.Prefekt = "Bolibompas hushåll";

            institutioner.Add(institution1);
            #endregion

            #region institution2
            Institution institution2 = new Institution();
            institution2.InstID = unikInstID++;
            institution2.Namn = "Bollskall 2";
            institution2.Prefekt = "Melodi Kanten";

            institutioner.Add(institution2);
            #endregion
        }

    }
}
