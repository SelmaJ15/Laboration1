﻿using BusinessEntiteter;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLager
{
    public class ServiceLager
    {
        private InMemoryDatabas inmemorydatabas = new InMemoryDatabas();

        public int kursID { get; private set; }
        public int signatur { get; private set; }

        #region Hämta Listor
        public List<Kurs> HämtaListaMedKurs()
        {
            return inmemorydatabas.kurser;
        }
        public List<Institution> HämtaListaMedInstitution()
        {
            return inmemorydatabas.institutioner;
        }
        public List<Student> HämtaListaMedStudent()
        {
            return inmemorydatabas.studenter;
        }
        public List<Lärare> HämtaListaMedLärare()
        {
            return inmemorydatabas.lärare;
        }
        #endregion Hämta Listor

        #region Ta Bort

        public void TaBortLärare(Lärare lärare)
        {
            inmemorydatabas.lärare.Remove(lärare);
        }
        public void TaBortStudent(Student studenter)
        {
            inmemorydatabas.studenter.Remove(studenter);
        }
        public void TaBortKurs(Kurs kurser)
        {
            inmemorydatabas.kurser.Remove(kurser);
        }
        public void TaBortInstitution(Institution institutioner)
        {
            inmemorydatabas.institutioner.Remove(institutioner);
        }
        #endregion Ta Bort

        #region Lägg till
        public void LäggTillStudent(Student studenter)
        {
            inmemorydatabas.studenter.Add(studenter);
        }
        public void LäggTillLärare(Lärare lärare)
        {
            inmemorydatabas.lärare.Add(lärare);
        }
        public void LäggTillKurs(Kurs kurser)
        {
            inmemorydatabas.kurser.Add(kurser);
        }
        public void LäggTillInstitution(Institution institutioner)
        {
            inmemorydatabas.institutioner.Add(institutioner);
        }
        #endregion Lägg till
        #region Association lärare och kurs
        public void AssocieraLärareMedKurs(string Signatur, string KursID, bool påAv)
        {
            Lärare lärarData = inmemorydatabas.lärare.Find(s => s.Signatur == signatur);
            Kurs KursData = inmemorydatabas.kurser.Find(k => k.KursID == kursID);

            if (lärarData == null)
                throw new Exception($"Läraren {signatur} finns inte");
            else if (KursData == null)
                throw new Exception($"Kursen {kursID} finns inte");

            if (påAv)
            {
                if (lärarData.Kurser.Contains(KursData) && KursData.Undervisare.Contains(lärarData))
                    throw new Exception($"Associationen {signatur}-{kursID} finns redan");
                else
                {
                    lärarData.Kurser.Add(KursData);
                    KursData.Undervisare.Add(lärarData);
                }
            }
            else
            {
                lärarData.Kurser.Remove(KursData);
                KursData.Undervisare.Remove(lärarData);
            }
        }
        #endregion
        public void Seed()
        {
            inmemorydatabas.Seed();
        }
    }
}
